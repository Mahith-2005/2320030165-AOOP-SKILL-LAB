package decorator.coffeeshop

import decorator.coffeeshop.Beverage

/**
 * Created by devansh on 28/08/20.
 */

abstract class CondimentDecorator : Beverage()